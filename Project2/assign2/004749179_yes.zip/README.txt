Look for texture object that is colored like a rainbow. The edges are obvious to see.
The texturing was made to wrap the image around the object both inside the object and outside.
the sides of the object just took the image like a layover.

The over all project was to create a first person shooter. I wanted to make a game out of it
by creating moving enemies/targets but I quickly learned that the complexity was greater than I
imagined. 

I wanted to also include bullet drop and bullet speed. I used a decaying exponential 
to slow the bullet down as it got further away. I used a parabolic expression to simulate gravity
on the bullet. 

I ran into trouble with movement numerous times. I finally decided to let 
the user push only one button at a time to eleminate the problems that I was having. 

Bullet collision was a task in its own. the closer the object to be hit was, the less likely it was
to be hit. This was because the bullet would sometimes pass right through the object without registering
a hit. I added different sounds for when the bullet hit different objects. 

The animation when firing the bullet took the most time to create being that it was the first thing
that I did and I had little knowledge of what was happening at the time.

Overall I am very pleased with this project and wished I had more time to add the things I wanted.

